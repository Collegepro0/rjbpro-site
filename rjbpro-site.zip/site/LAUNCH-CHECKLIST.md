# RJB Pro — Launch Checklist

## Before launch (in order)
1. **Forms**: create two free forms at formspree.io. Replace `YOUR_FORM_ID` in
   `contact-us/index.html` and `subcontractors/index.html`.
2. **Logo**: save your logo to `/images/rjb-logo.png` (ideally a white/knockout
   version for the dark nav) and update the `src` in every page's nav + footer.
   Find/replace: `https://rjbpro.com/wp-content/uploads/2023/06/RJB-Logo-WithDescriptor.png`
3. **Photos**: replace Unsplash placeholder URLs with RJB photography as the
   shoot delivers. Each page's image locations are commented at the top of the file.
4. **Content verification**:
   - Projects page: replace all 9 sample projects with real ones (check client
     confidentiality/MSA terms before naming clients).
   - About page: fill in the leadership grid; verify timeline decades.
   - Confirm the 48-states claim or adjust phrasing.
   - Testimonial on homepage: use exact approved quote + attribution.
5. **Favicon**: add `favicon.ico` to the site root.

## Hosting (Cloudflare Pages — free)
1. Create a Cloudflare account; Pages -> Create project -> Direct upload.
2. Drag this whole folder in. You get a preview URL immediately.
3. Verify every page and form on the preview URL.
4. Add custom domain rjbpro.com in the Pages project; update DNS as instructed.
5. The `_redirects` file maps all old URLs to new pages automatically — do not delete it.

## After launch
- Submit the new sitemap in Google Search Console.
- Watch Search Console for 404s the first two weeks; add any missed redirects.
- Content cadence: one insight/month, new projects quarterly.
